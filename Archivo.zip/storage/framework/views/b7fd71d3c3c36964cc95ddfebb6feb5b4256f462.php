<?php /* /Users/nicolas/Sites/app_los_laureles/resources/views/productos/listar.blade.php */ ?>
<?php $__env->startSection('content'); ?>
    <section class="container__producto row justify-content-center">
        <div class="cart" style="display: none">
            <h2> Cart </h2>
            <hr>
        </div>
        <div class="producto">
            <img src="<?php echo e(asset('imagenes/juice.png')); ?>" alt="Juice" class="producto__imagen">
            <h2 class="producto__nombre">Juice</h2>
            <h3 class="producto__precio">$990</h3>            
            <button class="btn btn-success btn-block" data-action="addToCart" id="btn__add"> agregar a la canasta</button>
        </div>
        <div class="producto">
            <img src="<?php echo e(asset('imagenes/banana.png')); ?>" class="producto__imagen" alt="banana">               
            <h2 class="producto__nombre">banana</h2>
            <h3 class="producto__precio">$2090</h3>
            <button class="btn btn-success btn-block" data-action="addToCart" id="btn__add"> agregar a la canasta</button>
        </div>
        <div class="producto">
            <img src="<?php echo e(asset('imagenes/bread.png')); ?>" alt="Bread" class="producto__imagen">
            <h2 class="producto__nombre">Bread</h2>
            <h3 class="producto__precio">$1090</h3>            
            <button class="btn btn-success btn-block" data-action="addToCart" id="btn__add"> agregar a la canasta</button>
        </div>
        <div class="producto">
            <img src="<?php echo e(asset('imagenes/coke.png')); ?>" alt="Coke" class="producto__imagen">
            <h2 class="producto__nombre">Coke</h2>
            <h3 class="producto__precio">$990</h3>            
            <button class="btn btn-success btn-block" data-action="addToCart" id="btn__add"> agregar a la canasta</button>
        </div>
    </section>


<?php $__env->stopSection(); ?>






<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>