<?php /* /Users/nicolas/Sites/app_los_laureles/resources/views/layouts/main.blade.php */ ?>
<!DOCTYPE html>
<html>
<!-- ---- MODIFICAR LOS CSS Y JS POR ESTATICOS DEL PROYECTO --- -->
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery.perfect-scrollbar/1.4.0/css/perfect-scrollbar.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('css/sidebar.menu.css')); ?>">
    <link rel="stylesheet" href='https://use.fontawesome.com/releases/v5.7.0/css/all.css' 
    integrity='sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ' 
    crossorigin='anonymous'>>
    <link rel="stylesheet" href="<?php echo e(asset('css/sidebar.menu.white.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('plugins/bootstrap/css/bootstrap.min.css')); ?>">
    <script src="<?php echo e(asset('plugins/jquery/jquery-3.3.1.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/bootstrap/js/bootstrap.bundle.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/bootstrap/js/bootstrap.min.js')); ?>"></script>
	<title>Los Laureles</title>
</head>

<body>
    <div class="d-flex" id="wrapper" height="100%">
            <!-- menu lateral -->
            <div class="sidebar bg-white-menu">
                <div class="menu">
                    <!-- menu general -->
                    <ul class="menu scrollbar">
                        <!-- submenu -->
                        <li>
                            <span class="name">Categorias</span>
                            <ul>
                                <li class="parent">
                                    <a href="#" class="employ current"><i class="fa fa-cart-plus" aria-hidden="true"></i>Abarrotes</a>
                                    <ul class="submenu">
                                        <li><a href="#">Aceite</a></li>
                                        <li><a href="#">Arroz</a></li>
                                        <li><a href="#">Atun</a></li>
                                        <li><a href="#">Azucar</a></li>
                                        <li><a href="#">Café</a></li>
                                        <li><a href="#">Cholgas</a></li>
                                        <li><a href="#">Choritos</a></li>
                                        <li><a href="#">Chuño</a></li>
                                        <li><a href="#">Crema de Coco</a></li>
                                        <li><a href="#">Cubo Caldo Maggi</a></li>
                                        <li><a href="#">Dulce Membrillo</a></li>
                                        <li><a href="#">Durazno en Tarro</a></li>
                                        <li><a href="#">Esparragos</a></li>
                                        <li><a href="#">Fideos</a></li>
                                        <li><a href="#">Fondos Alcachofas</a></li>
                                        <li><a href="#">Frutillas en Tarro</a></li>
                                        <li><a href="#">Garbanzos</a></li>
                                        <li><a href="#">Harina</a></li>
                                        <li><a href="#">Jurel</a></li>
                                        <li><a href="#">Ketchup</a></li>
                                        <li><a href="#">Lentejas</a></li>
                                    </ul>
                                </li>
                                <li class="parent">
                                    <a href="#" class="employ current"><i class="fa fa-tint" aria-hidden="true"></i>Bebidas</a>
                                    <ul class="submenu">
                                        <li><a href="#">Fantasia</a></li>
                                        <li><a href="#">Aloe Vera</a></li>
                                        <li><a href="#">Energeticas</a></li>
                                        <li><a href="#">Jugos</a></li>
                                    </ul>
                                </li>
                                <li><a href="#"><i class="fa fa-leaf" aria-hidden="true"></i>Cereales</a></li>
                                <li class="parent">
                                    <a href="#" class="employ current"><i class="fa fa-cog" aria-hidden="true"></i>Condimentos</a>
                                    <ul class="submenu">
                                        <li><a href="#">Ají</a></li>
                                        <li><a href="#">Almendras</a></li>
                                        <li><a href="#">Arandanos</a></li>
                                        <li><a href="#">Avena</a></li>
                                        <li><a href="#">Champiñones secos</a></li>
                                        <li><a href="#">Canela</a></li>
                                        <li><a href="#">Chia</a></li>
                                        <li><a href="#">Ciruelas</a></li>
                                        <li><a href="#">Coco</a></li>
                                        <li><a href="#">Comino</a></li>
                                        <li><a href="#">Cramberries</a></li>
                                        <li><a href="#">Damascos</a></li>
                                        <li><a href="#">Datiles</a></li>
                                        <li><a href="#">Goji</a></li>
                                        <li><a href="#">Granola</a></li>
                                        <li><a href="#">Harina de Almendras</a></li>
                                        <li><a href="#">Higos</a></li>
                                        <li><a href="#">Huesillos</a></li>
                                        <li><a href="#">Linaza</a></li>
                                        <li><a href="#">Mani</a></li>
                                    </ul>
                                </li>
                                <li class="parent">
                                    <a href="#" class="employ current"><i class="fa fa-cog" aria-hidden="true"></i>Congelados</a>
                                    <ul class="submenu">
                                        <li><a href="#">Choclo</a></li>
                                        <li><a href="#">Empanaditas</a></li>
                                        <li><a href="#">Frutos del Bosque</a></li>
                                        <li><a href="#">Habas</a></li>
                                        <li><a href="#">Jardinera</a></li>
                                        <li><a href="#">Jugo de Limon</a></li>
                                        <li><a href="#">Masas</a></li>
                                        <li><a href="#">Porotos</a></li>
                                        <li><a href="#">Pulpas</a></li>
                                    </ul>
                                </li>
                                <li><a href="#"><i class="fa fa-home" aria-hidden="true"></i>Elementos de Limpieza</a></li>
                                <li><a href="#"><i class="fa fa-home" aria-hidden="true"></i>Encurtidos</a></li>
                                <li><a href="#"><i class="fa fa-home" aria-hidden="true"></i>Huevos de Gallina Libre</a></li>
                                <li><a href="#"><i class="fa fa-home" aria-hidden="true"></i>Abarrotes</a></li>
                                <li><a href="#"><i class="fa fa-home" aria-hidden="true"></i>Pan, Galletas y Golosinas</a></li>
                                <li><a href="#"><i class="fa fa-home" aria-hidden="true"></i>Papel Higenico y Otros</a></li>
                                <li><a href="#"><i class="fa fa-home" aria-hidden="true"></i>Plasticos y Desechables</a></li>
                                <li><a href="#"><i class="fa fa-home" aria-hidden="true"></i>Ofertas y Otros</a></li>
                            </ul>
                        </li>
    
    
                        <li>
                            <span class="name">Listas</span>
                            <ul>
                                <li><a href="#"><i class="fa fa-plus" aria-hidden="true"></i>Agregar Lista</a></li>
                                <li><a href="#"><i class="fa fa-table" aria-hidden="true"></i>Mis Listas</a></li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </div>
    
            <!-- Contenido del Sitio -->
            <div class="col-xs-12 col-md-9 content" height="100%">
                <nav class="navbar navbar-expand-lg fixed-top bg-white-navbar">
                    <img src="/img/laureles.png" alt="">
                    <a class="navbar-brand navbar-title" href="#">Despensa Los Laureles</a>
                    <span class="navbar-text">
                        <a href="#" id="sidebar" class="bars">
                            <i class="fa fa-bars" aria-hidden="true"></i>
                        </a>
                    </span>
                    <div class="shop-cart">
                        <a class="btn" href="#">
                            <i class="fas fa-shopping-basket bask" style='font-size:24px;color:#fbbc1e'></i>
                            <div class="pick-up">
                                <p class="cart__items__quantity"> 0 </p>
                            </div>
                        </a>
                    </div>
                </nav>
                <section class="container__producto row justify-content-center">
                    <div class="cart" style="display: none">
                        <h2> Cart </h2>
                        <hr>
                        <div class="cart-buttons">
                            <button class="btn btn-info btn-block" style="display:none">Agregar a la Lista</button>
                            <button class="btn btn-secondary btn-block">Crear Lista</button>
                        </div>
                    </div> 
                    <?php echo $__env->yieldContent('content'); ?>
                </section>
            </div>
        </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1"
    crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.perfect-scrollbar/1.4.0/perfect-scrollbar.min.js"></script>
    <script src="<?php echo e(asset('js/sidebar.menu.js')); ?>"></script>
    <script src="<?php echo e(asset('js/script.js')); ?>"></script>

    <script>
       $(function () {
           new PerfectScrollbar('.scrollbar');
       });
    </script>
</body>

</html>