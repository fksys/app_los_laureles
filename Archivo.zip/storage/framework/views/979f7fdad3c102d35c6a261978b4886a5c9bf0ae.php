<?php /* /Users/nicolas/Sites/app_los_laureles/resources/views/welcome.blade.php */ ?>
	
		<!-- menu lateral -->
		
		<!-- Contenido del Sitio -->
		<?php $__env->startSection('content'); ?>
			<?php echo $__env->make('layouts.content', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<?php $__env->stopSection(); ?>
	

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>