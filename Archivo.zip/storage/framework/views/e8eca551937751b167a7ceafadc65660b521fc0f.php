<?php /* /Users/nicolas/Sites/app_los_laureles/resources/views/layouts/content.blade.php */ ?>
<div class="container-fluid">
    <h1>Despensa Los Laureles</h1>
    <div class="box bg-white">
        <h3>Contenido Principal</h3>
        <p>Contenido</p>
    </div>
    <div class="row">
        <div class="col-6 col-md-6">
            <div class="box bg-white">
                <h3>Contenido Secundario</h3>
                <p> Contenido</p>
            </div>
        </div>
        <div class="col-6 col-md-6">
            <div class="box bg-white">
                <h3>Contenido Secundario</h3>
                <p> Contenido</p>
            </div>
        </div>
    </div>
</div>