@extends('layouts.main')
	
		<!-- menu lateral -->
		
		<!-- Contenido del Sitio -->
		@section('content')
			@include('layouts.content')
		@endsection
	
