@extends('layouts.main')

@section('content')
        <div class="producto">
            <img src="{{ asset('imagenes/juice.png')}}" alt="Juice" class="producto__imagen">
            <h2 class="producto__nombre">Juice</h2>
            <h3 class="producto__precio">$990</h3>            
            <button class="btn btn-success btn-block" data-action="addToCart" id="btn__add"> agregar a la canasta</button>
        </div>
        <div class="producto">
            <img src="{{ asset('imagenes/banana.png')}}" class="producto__imagen" alt="banana">               
            <h2 class="producto__nombre">banana</h2>
            <h3 class="producto__precio">$2090</h3>
            <button class="btn btn-success btn-block" data-action="addToCart" id="btn__add"> agregar a la canasta</button>
        </div>
        <div class="producto">
            <img src="{{ asset('imagenes/bread.png')}}" alt="Bread" class="producto__imagen">
            <h2 class="producto__nombre">Bread</h2>
            <h3 class="producto__precio">$1090</h3>            
            <button class="btn btn-success btn-block" data-action="addToCart" id="btn__add"> agregar a la canasta</button>
        </div>
        <div class="producto">
            <img src="{{ asset('imagenes/coke.png')}}" alt="Coke" class="producto__imagen">
            <h2 class="producto__nombre">Coke</h2>
            <h3 class="producto__precio">$990</h3>            
            <button class="btn btn-success btn-block" data-action="addToCart" id="btn__add"> agregar a la canasta</button>
        </div>
   


@endsection





